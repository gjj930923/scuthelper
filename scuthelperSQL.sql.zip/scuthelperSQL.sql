-- phpMyAdmin SQL Dump
-- version 3.3.8.1
-- http://www.phpmyadmin.net
--
-- 主机: w.rdc.sae.sina.com.cn:3307
-- 生成日期: 2016 年 11 月 25 日 07:42
-- 服务器版本: 5.6.23
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `app_scuthelper`
--

-- --------------------------------------------------------

--
-- 表的结构 `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `addresses`
--

INSERT INTO `addresses` (`address_id`, `content`) VALUES
(5, 'C5'),
(6, 'C9东'),
(7, 'C11'),
(8, 'C10'),
(9, 'C1'),
(10, 'C2'),
(11, '西十六'),
(12, ''),
(13, '北三');

-- --------------------------------------------------------

--
-- 表的结构 `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `administrator`
--

INSERT INTO `administrator` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'admin', '9fee942ba6006aae3a8943e03c53b118');

-- --------------------------------------------------------

--
-- 表的结构 `administrator_settings`
--

CREATE TABLE IF NOT EXISTS `administrator_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_mode` tinyint(1) NOT NULL DEFAULT '0',
  `start_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weibo_access_token` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `administrator_settings`
--

INSERT INTO `administrator_settings` (`setting_id`, `holiday_mode`, `start_code`, `weibo_access_token`) VALUES
(1, 0, 'JeGXnigU9VWHnzOATH0Twd7ATpXhlLCa', '2.00OxEhgF2889ED99aeb52961p4rXgC');

-- --------------------------------------------------------

--
-- 表的结构 `campuses`
--

CREATE TABLE IF NOT EXISTS `campuses` (
  `campus_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`campus_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `campuses`
--

INSERT INTO `campuses` (`campus_id`, `name`) VALUES
(1, '大学城校区'),
(2, '五山校区');

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_category` int(11) DEFAULT '0',
  `name` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `parent_category` (`parent_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=108 ;

--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`category_id`, `parent_category`, `name`) VALUES
(1, 0, '图书'),
(2, 0, '音像软件'),
(3, 0, '数码及配件'),
(4, 0, '家居'),
(5, 0, '电脑设备'),
(6, 0, '办公及学生用品'),
(7, 0, '票券'),
(8, 0, '电器'),
(9, 0, '美妆'),
(10, 0, '食品'),
(11, 0, '运动户外'),
(12, 0, '服装'),
(13, 0, '鞋靴'),
(14, 0, '箱包'),
(15, 0, '手表眼镜'),
(16, 0, '虚拟物品'),
(17, 1, '教材'),
(18, 1, '教辅'),
(19, 1, '文学艺术'),
(20, 1, '人文社科'),
(21, 1, '经济管理'),
(22, 1, '励志成功'),
(23, 1, '科技'),
(24, 1, '生活'),
(25, 1, '其他'),
(26, 2, '影视'),
(27, 2, '音乐'),
(28, 2, '乐器'),
(29, 2, '游戏'),
(30, 2, '软件'),
(31, 2, '其他'),
(32, 3, '手机'),
(33, 3, '平板电脑'),
(34, 3, '智能设备'),
(35, 3, '摄像机'),
(36, 3, '音乐播放器'),
(37, 3, '手机配件'),
(38, 3, '摄像机配件'),
(39, 3, '其他'),
(40, 4, '家纺'),
(41, 4, '家具'),
(42, 4, '生活日用'),
(43, 4, '装饰'),
(44, 4, '其他'),
(45, 5, '电脑整机'),
(46, 5, '电脑外设'),
(47, 5, '存储产品'),
(48, 5, '网络产品'),
(49, 5, '电脑DIY组件'),
(50, 5, '其他'),
(51, 6, '笔、笔记本'),
(52, 6, '计算器'),
(53, 6, '文档管理'),
(54, 6, '电子词典'),
(55, 6, '桌上用品'),
(56, 6, '其他'),
(57, 7, '门票'),
(58, 7, '电影票'),
(59, 7, '讲座票'),
(60, 7, '其他'),
(61, 8, '电视、音响'),
(62, 8, '厨房电器'),
(63, 8, '个人护理电器'),
(64, 8, '居家电器'),
(65, 8, '其他'),
(66, 9, '女士护理'),
(67, 9, '男士护理'),
(68, 9, '眼睛护理'),
(69, 9, '其他'),
(70, 10, '饮料'),
(71, 10, '酒水'),
(72, 10, '冲调'),
(73, 10, '零食'),
(74, 10, '方便食品'),
(75, 10, '保健食品'),
(76, 11, '装备'),
(77, 11, '鞋'),
(78, 11, '自行车'),
(79, 11, '健身训练'),
(80, 11, '体育用品'),
(81, 12, '女装'),
(82, 12, '男装'),
(83, 12, '毛衣'),
(84, 12, '羽绒服'),
(85, 12, '外套'),
(86, 12, '牛仔裤'),
(87, 12, '其他'),
(88, 13, '女鞋'),
(89, 13, '男鞋'),
(90, 13, '帆布鞋'),
(91, 13, '拖鞋'),
(92, 13, '凉鞋'),
(93, 13, '其他'),
(94, 14, '女包'),
(95, 14, '男包'),
(96, 14, '单肩包'),
(97, 14, '拉杆箱'),
(98, 14, '钱包'),
(99, 14, '电脑包'),
(100, 14, '户外包'),
(101, 14, '其他'),
(102, 15, '手表'),
(103, 15, '眼镜'),
(104, 16, '网游'),
(105, 16, 'F码'),
(106, 16, '优惠码'),
(107, 16, '其他');

-- --------------------------------------------------------

--
-- 表的结构 `favour`
--

CREATE TABLE IF NOT EXISTS `favour` (
  `favour_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`favour_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `favour`
--


-- --------------------------------------------------------

--
-- 表的结构 `feedbacks`
--

CREATE TABLE IF NOT EXISTS `feedbacks` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `release_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` varchar(800) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `sender_id` int(11) NOT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `feedbacks`
--

INSERT INTO `feedbacks` (`feedback_id`, `release_time`, `content`, `is_read`, `sender_id`) VALUES
(1, '2016-06-05 22:55:29', '这个网站做得很棒！希望能有不断的进步！', 1, 30),
(2, '2016-06-05 22:57:45', '网站做得非常棒！希望能有更多同学在这里发布信息！', 1, 30);

-- --------------------------------------------------------

--
-- 表的结构 `login_records`
--

CREATE TABLE IF NOT EXISTS `login_records` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `login_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `login_ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`record_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=53 ;

--
-- 转存表中的数据 `login_records`
--

INSERT INTO `login_records` (`record_id`, `user_id`, `login_time`, `login_ip`) VALUES
(1, 30, '2016-06-05 22:40:10', '221.4.34.50'),
(2, 30, '2016-06-05 22:41:53', '221.4.34.50'),
(3, 30, '2016-06-05 22:48:50', '221.4.34.50'),
(4, 30, '2016-06-05 22:52:16', '221.4.34.50'),
(5, 30, '2016-06-06 00:00:44', '14.17.37.43'),
(6, 30, '2016-06-06 10:17:21', '221.4.34.50'),
(7, 30, '2016-06-06 10:18:33', '221.4.34.50'),
(8, 30, '2016-06-06 11:02:48', '221.4.34.50'),
(9, 30, '2016-06-06 11:16:59', '221.4.34.50'),
(10, 30, '2016-06-06 11:36:50', '221.4.34.50'),
(11, 30, '2016-06-06 11:41:24', '221.4.34.50'),
(12, 30, '2016-06-06 11:47:07', '221.4.34.50'),
(13, 30, '2016-06-06 11:47:42', '221.4.34.50'),
(14, 30, '2016-06-06 12:01:27', '221.4.34.50'),
(15, 29, '2016-06-12 21:02:16', '221.4.34.33'),
(16, 30, '2016-06-14 20:31:00', '221.4.34.50'),
(17, 30, '2016-06-15 15:20:16', '221.4.34.50'),
(18, 30, '2016-06-16 11:39:20', '221.4.34.50'),
(19, 30, '2016-06-16 11:55:29', '221.4.34.50'),
(20, 30, '2016-06-16 16:34:08', '221.4.34.50'),
(21, 30, '2016-06-16 16:53:53', '221.4.34.50'),
(22, 30, '2016-06-16 19:36:24', '221.4.34.50'),
(23, 30, '2016-06-16 21:07:26', '221.4.34.50'),
(24, 30, '2016-06-17 20:13:46', '221.4.34.50'),
(25, 30, '2016-06-17 23:40:19', '221.4.34.50'),
(26, 30, '2016-06-17 23:56:09', '221.4.34.50'),
(27, 30, '2016-06-18 00:11:01', '221.4.34.50'),
(28, 30, '2016-06-18 00:15:19', '221.4.34.50'),
(29, 30, '2016-06-18 09:56:14', '110.64.91.99'),
(30, 30, '2016-06-18 10:04:26', '221.4.34.50'),
(31, 30, '2016-06-18 10:56:32', '221.4.34.50'),
(32, 30, '2016-06-18 11:08:21', '221.4.34.50'),
(33, 30, '2016-06-18 11:29:16', '221.4.34.50'),
(34, 30, '2016-06-18 16:30:14', '221.4.34.50'),
(35, 30, '2016-06-18 23:52:14', '221.4.34.50'),
(36, 30, '2016-06-18 23:59:17', '221.4.34.50'),
(37, 30, '2016-06-21 16:25:19', '221.4.34.50'),
(38, 30, '2016-06-21 16:31:44', '221.4.34.50'),
(39, 30, '2016-06-21 16:40:19', '221.4.34.50'),
(40, 31, '2016-06-22 14:29:32', '221.4.34.225'),
(41, 31, '2016-06-22 14:30:44', '221.4.34.225'),
(42, 30, '2016-06-22 22:17:51', '221.4.34.50'),
(43, 30, '2016-06-22 22:18:33', '221.4.34.50'),
(44, 30, '2016-06-22 22:53:37', '221.4.34.50'),
(45, 30, '2016-06-22 23:28:07', '221.4.34.50'),
(46, 30, '2016-06-23 22:19:25', '221.4.34.50'),
(47, 32, '2016-06-23 23:49:48', '14.17.37.144'),
(48, 30, '2016-06-25 21:19:46', '221.4.34.50'),
(49, 33, '2016-06-26 16:31:28', '221.4.34.6'),
(50, 34, '2016-06-26 23:40:02', '183.62.57.145'),
(51, 30, '2016-06-26 23:48:05', '221.4.34.50'),
(52, 35, '2016-07-01 15:03:05', '221.4.34.83');

-- --------------------------------------------------------

--
-- 表的结构 `majors`
--

CREATE TABLE IF NOT EXISTS `majors` (
  `major_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`major_id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `majors`
--

INSERT INTO `majors` (`major_id`, `school_id`, `name`) VALUES
(4, 1, '软件工程卓越班'),
(5, 1, '软件工程'),
(6, 6, '高分子'),
(7, 1, '4班'),
(8, 5, '3'),
(9, 1, '15级软件2班');

-- --------------------------------------------------------

--
-- 表的结构 `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '接收者id',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_id` int(11) NOT NULL,
  `send_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`message_id`),
  KEY `user_id` (`user_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `messages`
--

INSERT INTO `messages` (`message_id`, `user_id`, `title`, `content`, `sender_id`, `send_time`, `is_read`) VALUES
(1, 30, '【华工小助手】Hello', 'test', -1, '2016-06-05 23:49:25', 1),
(2, 30, '【华工小助手】您有待处理的求购请求！', '商品名称：软件测试原理与实践（英文版）<br>数量：1<br>期望交易价格：9.5<br>期望交易时间：2016-06-16 15:00:00<br>买家备注：hello<br>期望交易时间：2016-06-16 15:00:00<br>期望交易地点：C1-222<br>求购处理请访问：http://scuthelper.sinaapp.com/market/ordersAndProducts 并点击“求购信息待处理”', -1, '2016-06-15 15:54:37', 1),
(3, 30, '您有待处理的求购请求！', '商品名称：软件测试原理与实践（英文版）<br>数量：1<br>期望交易价格：9.5<br>期望交易时间：2016-06-18 15:00:00<br>买家备注：hello<br>期望交易地点：C1-222<br>求购处理请访问：http://scuthelper.sinaapp.com/market/ordersAndProducts 并点击“求购信息待处理”', -1, '2016-06-17 17:15:02', 1),
(4, 30, '您的求购请求已同意', '商品名称：软件测试原理与实践（英文版）<br>卖家姓名：郭俊嘉<br>卖家email：895931778@qq.com<br>卖家QQ：895931778<br>卖家手机号：15521184338<br>交易地点：C2 222<br>交易时间：2016-06-19 14:00:00<br>备注：seller notes', -1, '2016-06-17 20:10:46', 1),
(5, 30, '您的求购请求已被拒绝', '商品名称：软件测试原理与实践（英文版）<br>备注：seller notes', -1, '2016-06-17 20:12:24', 1),
(6, 30, '您的求购请求已被拒绝', '商品名称：GRE巴朗词表<br>备注：不出国要这干嘛。。', -1, '2016-06-18 00:03:19', 1);

-- --------------------------------------------------------

--
-- 表的结构 `message_log`
--

CREATE TABLE IF NOT EXISTS `message_log` (
  `content` varchar(30) NOT NULL,
  `create_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `message_log`
--

INSERT INTO `message_log` (`content`, `create_time`) VALUES
('3 parameters smtp_host, smtp_u', '0000-00-00 00:00:00'),
('1007 The from email format err', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `latest_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_amount` double NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `address1` int(11) NOT NULL,
  `address2` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buyer_note` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_note` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expect_exchange_time` datetime NOT NULL,
  `real_exchange_time` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `time`, `latest_time`, `payment_amount`, `quantity`, `address1`, `address2`, `buyer_note`, `seller_note`, `expect_exchange_time`, `real_exchange_time`, `status`) VALUES
(1, 30, 38, '2016-06-13 21:02:19', '2016-06-18 00:03:19', 12, 1, 5, '309', 'come on baby', '不出国要这干嘛。。', '2016-06-14 02:00:00', '2016-06-14 02:00:00', 3);

-- --------------------------------------------------------

--
-- 表的结构 `pictures`
--

CREATE TABLE IF NOT EXISTS `pictures` (
  `picture_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `subsequence` int(11) NOT NULL DEFAULT '1',
  `url` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`picture_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=108 ;

--
-- 转存表中的数据 `pictures`
--

INSERT INTO `pictures` (`picture_id`, `product_id`, `subsequence`, `url`) VALUES
(1, 34, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523053413229.jpg'),
(2, 34, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523053464373.jpg'),
(3, 34, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523053428088.jpg'),
(4, 35, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523352741191.jpg'),
(5, 35, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523352713135.jpg'),
(6, 35, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523352726966.jpg'),
(7, 36, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523383793322.jpg'),
(8, 36, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523383774086.jpg'),
(9, 36, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523383724833.jpg'),
(10, 37, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523401138433.jpg'),
(11, 37, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523401115780.jpg'),
(12, 37, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060523401122744.jpg'),
(13, 38, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060611474433967.jpg'),
(14, 38, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060611474433793.jpg'),
(15, 38, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060611474496126.jpg'),
(16, 39, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016060612012814116.jpg'),
(17, 40, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061222234530330.jpg'),
(18, 40, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061222234550331.jpg'),
(19, 41, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061723561178131.jpg'),
(20, 41, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061723561188431.jpg'),
(21, 41, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061723561125739.jpg'),
(22, 41, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061723561194342.jpg'),
(23, 42, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061723585132301.jpg'),
(24, 42, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061723585178064.jpg'),
(25, 43, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061810585630854.jpg'),
(26, 43, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061810585698725.jpg'),
(27, 43, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061810585612478.jpg'),
(28, 44, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811221934424.jpg'),
(29, 45, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811282519639.JPG'),
(30, 45, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811282596007.JPG'),
(31, 45, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811282558316.JPG'),
(32, 45, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811282579127.JPG'),
(33, 45, 5, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811282597097.JPG'),
(34, 46, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811402668209.JPG'),
(35, 46, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811402687235.JPG'),
(36, 46, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811402654615.JPG'),
(37, 46, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811402667445.JPG'),
(38, 47, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811414916231.JPG'),
(39, 47, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811414960090.JPG'),
(40, 47, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811414942022.JPG'),
(41, 47, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811414988732.JPG'),
(42, 47, 5, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811414938240.JPG'),
(43, 48, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811491650731.jpg'),
(44, 48, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811491660560.jpg'),
(45, 48, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061811491632114.jpg'),
(46, 49, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816301576188.jpg'),
(47, 49, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816301510310.jpg'),
(48, 49, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816301594209.jpg'),
(49, 50, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816333499820.jpg'),
(50, 50, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816333485430.jpg'),
(51, 50, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816333495901.jpg'),
(52, 50, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816333468596.jpg'),
(53, 51, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816373548222.jpg'),
(54, 51, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816373587092.jpg'),
(55, 51, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816373535811.jpg'),
(56, 51, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816373599508.jpg'),
(57, 52, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816405911189.jpg'),
(58, 52, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816405944946.jpg'),
(59, 52, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816405935004.jpg'),
(60, 52, 4, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816405984735.jpg'),
(61, 53, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816432634874.jpg'),
(62, 53, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816432630241.jpg'),
(63, 53, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061816432691907.jpg'),
(64, 54, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823521782470.jpg'),
(65, 54, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823521725136.jpg'),
(66, 54, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823521769093.jpg'),
(67, 55, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823551160308.jpg'),
(68, 56, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823591966868.jpg'),
(69, 56, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823591945198.jpg'),
(70, 56, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016061823591978636.jpg'),
(71, 57, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116252193224.jpg'),
(72, 58, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116314649922.jpg'),
(73, 58, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116314624969.jpg'),
(74, 58, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116314621833.jpg'),
(75, 59, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116402512731.jpg'),
(76, 59, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116402566972.jpg'),
(77, 59, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116402593270.jpg'),
(78, 60, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116424579809.jpg'),
(79, 60, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062116424576757.jpg'),
(80, 61, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222183559704.jpg'),
(81, 62, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222225024967.jpg'),
(82, 62, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222225085958.jpg'),
(83, 63, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222260022909.jpg'),
(84, 63, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222260096776.jpg'),
(85, 64, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222315451974.jpg'),
(86, 64, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222315466485.jpg'),
(87, 65, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222365098964.jpg'),
(88, 66, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222481321499.jpg'),
(89, 67, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222533837583.jpg'),
(90, 68, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222552564610.jpg'),
(91, 68, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062222552539121.jpg'),
(92, 69, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223014479287.jpg'),
(93, 70, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223064099917.jpg'),
(94, 71, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223082438945.jpg'),
(95, 71, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223082497680.jpg'),
(96, 72, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223102626326.jpg'),
(97, 72, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223102685706.jpg'),
(98, 72, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223102643819.jpg'),
(99, 73, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223131862517.jpg'),
(100, 74, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223150386818.jpg'),
(101, 75, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062223281140148.jpg'),
(102, 76, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062623480767684.jpg'),
(103, 76, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062623480729779.jpg'),
(104, 77, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062623511644987.jpg'),
(105, 77, 2, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062623511629999.jpg'),
(106, 77, 3, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062623511649244.jpg'),
(107, 78, 1, 'http://77l5lx.com1.z0.glb.clouddn.com/scuthelper/market/upload_pic/2016062623570081650.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_price` double NOT NULL DEFAULT '0',
  `max_price` double NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `quantity_sold` int(11) NOT NULL DEFAULT '0',
  `fineness` int(11) NOT NULL,
  `description` varchar(600) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` int(11) NOT NULL,
  `times_read` int(11) NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `user_id` (`user_id`),
  KEY `category` (`category`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=79 ;

--
-- 转存表中的数据 `products`
--

INSERT INTO `products` (`product_id`, `user_id`, `name`, `min_price`, `max_price`, `category`, `quantity`, `quantity_sold`, `fineness`, `description`, `source`, `times_read`, `time`, `modify_time`, `is_deleted`) VALUES
(34, 30, '新GRE作文大讲堂方法、素材、题目剖析韦小亮', 14, 20, 18, 1, 0, 2, 'GRE作文必备书籍，内含作文写作策略和Issue部分素材大全，以及常见的argument破解方案。', 1, 1, '2016-06-05 23:08:46', '2016-06-05 23:21:09', 1),
(35, 30, '新GRE 作文', 14, 14, 18, 1, 0, 2, '天天天', 1, 0, '2016-06-05 23:36:01', '2016-06-05 23:36:52', 1),
(36, 30, '新GRE作文大讲堂 方法、素材、题目剖析', 14, 14, 18, 1, 0, 2, 'GRE作文备考必备。包含大量Issue素材、Argument常见类型和写作方法。', 1, 1, '2016-06-05 23:40:10', '2016-06-05 23:40:10', 0),
(37, 30, '软件测试原理与实践（英文版）', 9.5, 9.5, 17, 3, 2, 4, '软件工程教材，需要在课堂上使用.。。', 4, 3, '2016-06-05 23:41:39', '2016-06-18 00:01:29', 0),
(38, 30, 'GRE巴朗词表', 12, 12, 18, 2, 1, 3, 'GRE词汇系列，难度较大，但有相关习题帮助巩固词汇记忆。', 1, 2, '2016-06-06 11:50:39', '2016-06-18 10:25:09', 0),
(39, 30, 'test', 199, 199, 45, 1, 0, 4, '111', 2, 0, '2016-06-06 12:02:11', '2016-06-06 12:02:18', 1),
(40, 29, 'PHP和MySQL Web开发', 30, 30, 23, 1, 0, 3, 'php入门必备，对web开发感兴趣的你不可错过', 1, 2, '2016-06-12 22:26:19', '2016-06-12 22:26:19', 0),
(41, 30, 'SKG电饭煲 毕业转手卖出', 80, 80, 62, 1, 0, 3, '一号店西高地的，原价180。具体功能见图片，使用次数不超过10次。', 1, 0, '2016-06-17 23:58:50', '2016-06-17 23:58:50', 0),
(42, 30, '15公斤超大哑铃一对', 75, 75, 79, 1, 0, 3, '淘宝购买，使用两年左右，铃片使用水泥和塑料材质，可调整重量。', 1, 1, '2016-06-18 00:01:02', '2016-06-18 00:01:02', 0),
(43, 30, 'PHP程序开发范例宝典 含光盘', 60, 60, 23, 1, 0, 5, '两年前买的，没有任何笔记，可直接使用。现毕业需要转手～', 1, 0, '2016-06-18 11:01:47', '2016-06-18 11:01:47', 0),
(44, 30, 'test', 33, 33, 90, 1, 0, 5, '4444', 2, 0, '2016-06-18 11:22:52', '2016-06-18 11:23:01', 1),
(45, 30, '呃呃呃', 33, 33, 30, 1, 0, 5, '4444', 2, 0, '2016-06-18 11:29:00', '2016-06-18 11:29:06', 1),
(46, 30, '3333', 33, 33, 4, 1, 0, 5, '鹅鹅鹅饿我', 2, 0, '2016-06-18 11:40:50', '2016-06-18 11:40:58', 1),
(47, 30, 'eeee', 44, 44, 58, 1, 0, 5, 'qqqqq', 1, 1, '2016-06-18 11:42:20', '2016-06-18 11:49:06', 1),
(48, 30, '雅思阅读真经5', 34, 34, 1, 1, 0, 5, '大二时网上买的，一直没用过，改考托福了，毕业转手卖出', 1, 0, '2016-06-18 11:51:06', '2016-06-18 11:51:06', 0),
(49, 30, '新托福百日百句百篇 北美机经还原题 中', 10, 10, 18, 1, 0, 5, '托福机经汇总小册子，内容有点老了，但还是可供参考的。买了之后一直没动过', 1, 0, '2016-06-18 16:33:34', '2016-06-18 16:33:34', 0),
(50, 30, 'GRE考试官方指南 第2版', 38, 45, 18, 1, 0, 3, 'GRE考试官方指南。里面有样题，但已经完成了一部分。', 1, 1, '2016-06-18 16:37:35', '2016-06-18 16:37:35', 0),
(51, 30, '托福TOEFL考试官方指南 第4版', 40, 50, 18, 1, 0, 3, '托福考试官方指南 内有样题 部分题目已完成。另附光盘', 1, 1, '2016-06-18 16:40:59', '2016-06-18 16:40:59', 0),
(52, 30, '用户交互设计 有效的人机交互策略 英文第五版', 15, 15, 17, 1, 0, 4, '人机交互教材 主要针对计算机软件相关专业学生', 4, 1, '2016-06-18 16:43:26', '2016-06-18 16:43:26', 0),
(53, 30, '家居宿舍塑料收纳柜 五层', 15, 15, 41, 1, 0, 3, '可以直接放入宿舍书架里（如图） 用了两年但仍然能正常使用', 1, 0, '2016-06-18 16:45:55', '2016-06-18 16:45:55', 0),
(54, 30, '常远新托福写作真经 20套写作真题', 12, 12, 18, 1, 0, 3, '里面有大量真题和范文，包括综合写作里的阅读和听力部分，对托福写作备考有一定参考价值。', 1, 0, '2016-06-18 23:55:11', '2016-06-18 23:55:11', 0),
(55, 30, '17天搞定GRE单词', 0.01, 0.01, 18, 1, 0, 5, '介绍GRE词汇记忆法的小册子', 4, 0, '2016-06-18 23:56:42', '2016-06-18 23:56:42', 0),
(56, 30, '千万次摇摆，才能长大成人 金兰都著', 14, 14, 22, 1, 0, 5, '针对大学生的励志读物，讲述工作，学业，爱情。。', 1, 0, '2016-06-19 00:01:34', '2016-06-19 00:01:34', 0),
(57, 30, '聆听西方音乐', 35, 35, 17, 1, 0, 3, '人文通选课必备教材，期末需要使用此书参加开卷期末考。', 1, 0, '2016-06-21 16:29:09', '2016-06-21 16:29:09', 0),
(58, 30, '21天搞定新托福听力', 15, 15, 18, 1, 0, 3, '托福听力入门书，适合听力15分以下的同学练习，分类别练习，包含部分老托福题。已完成少部分。', 1, 0, '2016-06-21 16:36:56', '2016-06-21 16:36:56', 0),
(59, 30, '新托福阅读红宝书', 18, 18, 18, 1, 0, 4, '介绍托福阅读方法的书籍，新东方出版', 1, 0, '2016-06-21 16:42:45', '2016-06-21 16:42:45', 0),
(60, 30, '新托福口语红宝书', 18, 18, 18, 1, 0, 4, '介绍托福口语准备方法和模板的书籍，新东方出版', 1, 0, '2016-06-21 16:45:02', '2016-06-21 16:45:02', 0),
(61, 30, 'GRE词汇逆序记忆小词典', 5, 5, 18, 1, 0, 4, 'GRE词汇速记小册子，按照单词最后一个字母排序，并附带数学词汇汇总，有利于考前抱佛脚。。', 4, 0, '2016-06-22 22:22:49', '2016-06-22 22:22:49', 0),
(62, 30, '因为痛 所以叫青春 写给独自站在人生路口的你 金兰都著', 15, 15, 22, 1, 0, 4, '针对大学生的青春励志书籍', 1, 0, '2016-06-22 22:26:00', '2016-06-22 22:26:00', 0),
(63, 30, '中国高校之殇 武汉大学前校长刘道玉著', 10, 10, 20, 1, 0, 4, '毕业书籍转手，全书没有笔记基本全新。对中国高校发展关注并感兴趣的可以看看。。', 1, 0, '2016-06-22 22:31:53', '2016-06-22 22:31:53', 0),
(64, 30, '软件构架实践 第3版 影印版 英文版', 20, 20, 17, 1, 0, 3, '软件学院大三必修课教材 英文第三版 已标注考试重点', 1, 0, '2016-06-22 22:36:50', '2016-06-25 21:20:02', 0),
(65, 30, 'IT项目管理 英文原书 第6版', 10, 10, 17, 1, 0, 2, '软件学院专业必修课课本 书本比较残旧笔记比较多，但仍能使用', 5, 0, '2016-06-22 22:48:13', '2016-06-25 21:20:08', 0),
(66, 30, '中国近现代史刚要 2010修订版', 7, 7, 17, 1, 0, 4, '近代史课本你懂的', 4, 0, '2016-06-22 22:49:27', '2016-06-22 22:49:27', 0),
(67, 30, '大学物理实验课本', 10, 10, 17, 1, 0, 3, '华工大物实验参考书，必备', 4, 0, '2016-06-22 22:55:25', '2016-06-22 22:55:25', 0),
(68, 30, 'XML编程与应用教程', 5, 5, 17, 1, 0, 3, '计算机软件相关专业的课本', 4, 2, '2016-06-22 23:01:44', '2016-06-22 23:01:44', 0),
(69, 30, '新东方 四级词汇 词根+联想记忆法 乱序版', 8, 8, 18, 1, 0, 3, '高中的时候开始用到现在了，很经典的四六级词汇书！', 4, 0, '2016-06-22 23:06:39', '2016-06-22 23:06:39', 0),
(70, 30, '计算机组成与嵌入式系统 英文版 第6版', 15, 15, 17, 1, 0, 3, '软件学院计组课教材 针对大二的', 5, 0, '2016-06-22 23:08:24', '2016-06-22 23:08:24', 0),
(71, 30, '别告诉我你懂PPT', 15, 15, 21, 1, 0, 5, '介绍PPT的一本参考书', 1, 0, '2016-06-22 23:10:25', '2016-06-22 23:10:25', 0),
(72, 30, '电工学下册 电子技术辅导及习题讲解', 10, 10, 18, 1, 0, 4, '电工相关课程的教辅手册，对加强课堂知识掌握程度有一定帮助', 4, 0, '2016-06-22 23:13:18', '2016-06-22 23:13:18', 0),
(73, 30, '无主之地2 Borderlands2', 3, 3, 29, 1, 0, 5, '游戏碟', 5, 0, '2016-06-22 23:15:03', '2016-06-22 23:15:03', 0),
(74, 30, '热血无赖 Sleeping Dogs', 3, 3, 29, 1, 0, 5, '游戏碟', 5, 0, '2016-06-22 23:16:12', '2016-06-22 23:16:12', 0),
(75, 30, '有线键盘和无线鼠标', 25, 25, 46, 1, 0, 2, '毕业转手 已用两年多 功能正常', 4, 1, '2016-06-22 23:30:04', '2016-06-22 23:30:04', 0),
(76, 30, '数据结构与算法分析 C++版 第二版英文', 15, 15, 17, 1, 0, 4, '软院大二数据结构教材，和第三版大致相同，上课可使用', 4, 0, '2016-06-26 23:51:15', '2016-06-26 23:51:15', 0),
(77, 30, '瑞士军刀电脑挎包', 80, 80, 99, 1, 0, 4, '买了多年因为后来有了个新电脑包，所以没怎么用，接近全新，现毕业转手，毕业后打算留广州学习或工作的亲们也可购买！', 1, 0, '2016-06-26 23:56:40', '2016-06-26 23:56:40', 0),
(78, 30, '飞科吹风筒', 20, 20, 63, 1, 0, 4, '京东上买的，两年左右但少用，现毕业打算转手，毕业后留在广州学习工作的也能买！', 1, 0, '2016-06-26 23:59:39', '2016-06-26 23:59:39', 0);

-- --------------------------------------------------------

--
-- 表的结构 `q_and_a`
--

CREATE TABLE IF NOT EXISTS `q_and_a` (
  `QA_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `question` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`QA_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `q_and_a`
--

INSERT INTO `q_and_a` (`QA_id`, `product_id`, `status`, `is_public`, `user_id`, `question`, `answer`, `release_time`, `modify_time`) VALUES
(1, 37, 2, 1, 30, '请问软件测试这门课是什么时候开的？', '大三的第二学期', '2016-06-06 10:40:58', '2016-06-06 10:41:47');

-- --------------------------------------------------------

--
-- 表的结构 `recommendation_records`
--

CREATE TABLE IF NOT EXISTS `recommendation_records` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reason` int(11) NOT NULL,
  PRIMARY KEY (`record_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `recommendation_records`
--

INSERT INTO `recommendation_records` (`record_id`, `user_id`, `product_id`, `time`, `reason`) VALUES
(1, 30, 38, '2016-06-06 23:30:15', 2),
(2, 30, 50, '2016-06-18 23:30:15', 2),
(3, 30, 55, '2016-06-19 23:30:14', 2),
(4, 30, 61, '2016-06-22 23:30:14', 2);

-- --------------------------------------------------------

--
-- 表的结构 `schools`
--

CREATE TABLE IF NOT EXISTS `schools` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=29 ;

--
-- 转存表中的数据 `schools`
--

INSERT INTO `schools` (`school_id`, `name`) VALUES
(1, '软件学院'),
(2, '机械与汽车工程学院'),
(3, '建筑学院'),
(4, '土木与交通学院'),
(5, '电子与信息学院'),
(6, '材料科学与工程学院'),
(7, '化学与化工学院'),
(8, '轻工与食品学院'),
(9, '理学院'),
(10, '经济与贸易学院'),
(11, '自动化科学与工程学院'),
(12, '计算机科学与工程学院'),
(13, '电力学院'),
(14, '生物科学与工程学院'),
(15, '环境科学与工程学院'),
(16, '工商管理学院'),
(17, '创业教育学院'),
(18, '公共管理学院'),
(19, '思想政治学院'),
(20, '外国语学院'),
(21, '法学院知识产权学院'),
(22, '新闻与传播学院'),
(23, '艺术学院'),
(24, '体育学院'),
(25, '国际教育学院'),
(26, '国防生教育学院'),
(27, '设计学院'),
(28, '其他');

-- --------------------------------------------------------

--
-- 表的结构 `search_records`
--

CREATE TABLE IF NOT EXISTS `search_records` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `keyword` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`record_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `search_records`
--

INSERT INTO `search_records` (`record_id`, `user_id`, `keyword`, `time`) VALUES
(1, 30, 'GRE', '2016-06-06 10:39:52'),
(2, 30, 'GRE', '2016-06-06 11:07:52'),
(3, 30, 'IT', '2016-06-25 21:20:23');

-- --------------------------------------------------------

--
-- 表的结构 `similarities`
--

CREATE TABLE IF NOT EXISTS `similarities` (
  `product1` int(11) NOT NULL,
  `product2` int(11) NOT NULL,
  `similarity` double NOT NULL,
  PRIMARY KEY (`product1`,`product2`),
  KEY `product2` (`product2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `similarities`
--


-- --------------------------------------------------------

--
-- 表的结构 `subscribe`
--

CREATE TABLE IF NOT EXISTS `subscribe` (
  `subscribe_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`subscribe_id`),
  KEY `user_id` (`user_id`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `subscribe`
--


-- --------------------------------------------------------

--
-- 表的结构 `token_for_new_password`
--

CREATE TABLE IF NOT EXISTS `token_for_new_password` (
  `token` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`token`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `token_for_new_password`
--


-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `real_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(42) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_id` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qq` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_phone` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` smallint(6) NOT NULL DEFAULT '0',
  `address1` int(11) DEFAULT NULL,
  `address2` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campus` int(11) DEFAULT NULL,
  `school` int(11) DEFAULT NULL,
  `major` int(11) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `education` int(11) NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recommend_day` int(11) DEFAULT '6',
  `recommend_hour` int(11) NOT NULL DEFAULT '8',
  PRIMARY KEY (`user_id`),
  KEY `address1` (`address1`),
  KEY `campus` (`campus`),
  KEY `school` (`school`),
  KEY `major` (`major`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=36 ;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`user_id`, `real_name`, `nickname`, `password`, `student_id`, `email`, `qq`, `phone`, `short_phone`, `sex`, `address1`, `address2`, `campus`, `school`, `major`, `year`, `education`, `create_time`, `last_login_time`, `recommend_day`, `recommend_hour`) VALUES
(-2, '游客', '游客', '', '', '', '', '', '', 0, NULL, '', NULL, NULL, NULL, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, 8),
(-1, '', '管理员', '', '', '', '', '', '', 0, NULL, '', NULL, NULL, NULL, 2016, 0, '2016-04-10 23:03:12', '2016-04-10 23:03:12', 6, 8),
(29, '赖雍杰', 'yungkit', '15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225', '201230671323', 'ginolai@qq.com', '376192673', '13660544085', '', 3, 5, '309', 1, 1, 5, 2014, 0, '2016-05-05 20:31:22', '2016-06-12 21:02:16', 6, 8),
(30, '郭俊嘉', 'gjj930923', '5d79fe4b3cb2358ac3d4d2f314181878f2c0a6f641eab4bf086abaa7699a9010', '201236670504', '895931778@qq.com', '895931778', '15521184338', '', 1, 8, '308', 1, 1, 4, 2012, 0, '2016-06-05 22:40:10', '2016-06-26 23:48:05', 6, 10),
(31, '梁嘉豪', 'LiangJoe', 'c7afa9a26a2c81797e6284f7b3e4a060fbba4998da5ee66d240bb385231fadae', '201430270463', '757667419@qq.com', '757667419', '13424534226', '', 0, 11, '404', 2, 6, 6, 2014, 0, '2016-06-22 14:29:32', '2016-06-22 14:30:44', 6, 8),
(32, '钟晓玲', 'zzxl', '658c444d4530a4d324d285c6329332f8685c5d6ca10afa7d7fe8ba197d639eb5', '201230680257', '634067935@qq.com', '634067935', '13660254514', '', 0, 12, '', 1, 1, NULL, 0, 0, '2016-06-23 23:49:48', '2016-06-23 23:49:48', 6, 8),
(33, '梁耀友', '友', '5b293986986dd22f232c95cfa15c2ccbc29a761d3e4f54a8058578c5706fb56a', '201430612164', '869227113@qq.com', '869227113', '18826075808', '', 0, 8, '652', 1, 1, 7, 2014, 0, '2016-06-26 16:31:28', '2016-06-26 16:31:28', 6, 8),
(34, '罗家炜', 'law', '11bdfcf7d02c9ad3c0984f0459d0e84f5286854aa42cc75039d958b58e4b352e', '201430252308', '374549882@qq.com', '374549882', '18826077530', '77530', 0, 13, '801', 2, 5, 8, 2014, 0, '2016-06-26 23:40:02', '2016-06-26 23:40:02', 6, 8),
(35, '梁肖剑', 'USER0308', '909d7d0ae6b7bf93823c22be154c4940bb1f048a40a4f998d35ca27a1f5eeb64', '201530612149', '1341262679@qq.com', '1341262679', '13631433039', '', 1, 8, '429', 1, 1, 9, 15, 0, '2016-07-01 15:03:05', '2016-07-01 15:03:05', 6, 8);

-- --------------------------------------------------------

--
-- 表的结构 `visit_records`
--

CREATE TABLE IF NOT EXISTS `visit_records` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`record_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=33 ;

--
-- 转存表中的数据 `visit_records`
--

INSERT INTO `visit_records` (`record_id`, `user_id`, `product_id`, `time`) VALUES
(1, 30, 34, '2016-06-05 23:12:32'),
(2, 30, 35, '2016-06-05 23:36:34'),
(3, 30, 37, '2016-06-05 23:43:07'),
(4, 30, 37, '2016-06-06 10:40:28'),
(5, 30, 37, '2016-06-06 10:41:52'),
(6, 30, 37, '2016-06-06 10:42:43'),
(7, 30, 36, '2016-06-06 10:42:52'),
(8, 30, 37, '2016-06-06 11:03:26'),
(9, 29, 40, '2016-06-12 22:26:28'),
(10, 29, 40, '2016-06-12 22:27:54'),
(11, 29, 40, '2016-06-12 22:35:10'),
(12, 29, 37, '2016-06-12 22:35:52'),
(13, 29, 40, '2016-06-13 21:00:53'),
(14, 29, 38, '2016-06-13 21:01:04'),
(15, 29, 38, '2016-06-13 21:02:26'),
(16, 30, 38, '2016-06-15 15:36:29'),
(17, 30, 37, '2016-06-15 15:36:31'),
(18, 30, 38, '2016-06-16 11:39:22'),
(19, 30, 40, '2016-06-16 11:55:44'),
(20, 30, 40, '2016-06-16 19:36:56'),
(21, 30, 40, '2016-06-16 19:37:07'),
(22, 30, 40, '2016-06-16 19:37:08'),
(23, 30, 38, '2016-06-18 10:25:20'),
(24, 30, 47, '2016-06-18 11:46:40'),
(25, 30, 50, '2016-06-18 16:37:44'),
(26, 30, 42, '2016-06-18 20:45:24'),
(27, 30, 52, '2016-06-18 20:45:44'),
(28, 30, 51, '2016-06-18 20:46:04'),
(29, 31, 37, '2016-06-22 14:31:37'),
(30, 30, 68, '2016-06-22 23:16:27'),
(31, 32, 68, '2016-06-23 23:50:23'),
(32, 33, 75, '2016-06-26 16:32:30');

-- --------------------------------------------------------

--
-- 表的结构 `weibos`
--

CREATE TABLE IF NOT EXISTS `weibos` (
  `weibo_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `release_time` datetime NOT NULL,
  PRIMARY KEY (`weibo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=39 ;

--
-- 转存表中的数据 `weibos`
--

INSERT INTO `weibos` (`weibo_id`, `product_id`, `release_time`) VALUES
(1, 36, '2016-06-06 10:12:00'),
(2, 37, '2016-06-06 23:00:00'),
(3, 38, '2016-06-07 08:00:00'),
(4, 40, '2016-06-13 08:00:00'),
(5, 41, '2016-06-18 08:00:00'),
(6, 42, '2016-06-19 08:00:00'),
(7, 43, '2016-06-19 09:40:00'),
(8, 48, '2016-06-19 11:20:00'),
(9, 49, '2016-06-19 13:00:00'),
(10, 50, '2016-06-19 14:40:00'),
(11, 51, '2016-06-19 16:20:00'),
(12, 52, '2016-06-19 18:00:00'),
(13, 53, '2016-06-19 19:40:00'),
(14, 54, '2016-06-19 21:20:00'),
(15, 55, '2016-06-19 23:00:00'),
(16, 56, '2016-06-20 08:00:00'),
(17, 57, '2016-06-22 08:00:00'),
(18, 58, '2016-06-22 13:00:00'),
(19, 59, '2016-06-22 18:00:00'),
(20, 60, '2016-06-22 23:00:00'),
(21, 61, '2016-06-23 08:00:00'),
(22, 62, '2016-06-23 09:04:17'),
(23, 63, '2016-06-23 10:08:34'),
(24, 64, '2016-06-23 11:12:51'),
(25, 65, '2016-06-23 12:17:08'),
(26, 66, '2016-06-23 13:21:25'),
(27, 67, '2016-06-23 14:25:42'),
(28, 68, '2016-06-23 15:30:00'),
(29, 69, '2016-06-23 16:34:17'),
(30, 70, '2016-06-23 17:38:34'),
(31, 71, '2016-06-23 18:42:51'),
(32, 72, '2016-06-23 19:47:08'),
(33, 73, '2016-06-23 20:51:25'),
(34, 74, '2016-06-23 21:55:42'),
(35, 75, '2016-06-23 23:00:00'),
(36, 76, '2016-06-27 08:00:00'),
(37, 77, '2016-06-27 15:30:00'),
(38, 78, '2016-06-27 23:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `weibo_log`
--

CREATE TABLE IF NOT EXISTS `weibo_log` (
  `content` varchar(100) NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `weibo_log`
--

INSERT INTO `weibo_log` (`content`, `create_time`) VALUES
('-1', '2016-06-06 10:02:09'),
('-1', '2016-06-06 10:03:09'),
('20007 does multipart has image?', '2016-06-06 10:04:12'),
('0', '2016-06-06 10:12:10'),
('0', '2016-06-06 23:00:19'),
('0', '2016-06-07 08:00:21'),
('0', '2016-06-13 08:00:22'),
('0', '2016-06-18 08:00:21'),
('0', '2016-06-19 08:00:19'),
('0', '2016-06-19 09:40:19'),
('0', '2016-06-19 11:20:15'),
('0', '2016-06-19 13:00:19'),
('0', '2016-06-19 14:40:16'),
('0', '2016-06-19 16:20:14'),
('0', '2016-06-19 18:00:22'),
('0', '2016-06-19 19:40:15'),
('0', '2016-06-19 21:20:13'),
('0', '2016-06-19 23:00:18'),
('0', '2016-06-20 08:00:21'),
('0', '2016-06-22 08:00:19'),
('0', '2016-06-22 13:00:31'),
('0', '2016-06-22 18:00:22'),
('0', '2016-06-22 23:00:20'),
('0', '2016-06-23 08:00:21'),
('0', '2016-06-23 09:04:09'),
('0', '2016-06-23 10:08:12'),
('0', '2016-06-23 11:12:13'),
('0', '2016-06-23 12:17:11'),
('0', '2016-06-23 13:21:17'),
('0', '2016-06-23 14:25:11'),
('0', '2016-06-23 15:30:17'),
('0', '2016-06-23 16:34:12'),
('0', '2016-06-23 17:38:11'),
('0', '2016-06-23 18:42:14'),
('0', '2016-06-23 19:47:09'),
('0', '2016-06-23 20:51:15'),
('0', '2016-06-23 21:55:12'),
('0', '2016-06-23 23:00:20'),
('0', '2016-06-27 08:00:21'),
('0', '2016-06-27 15:30:19'),
('0', '2016-06-27 23:00:21');

--
-- 限制导出的表
--

--
-- 限制表 `favour`
--
ALTER TABLE `favour`
  ADD CONSTRAINT `favour_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `favour_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- 限制表 `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `login_records`
--
ALTER TABLE `login_records`
  ADD CONSTRAINT `login_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `majors`
--
ALTER TABLE `majors`
  ADD CONSTRAINT `majors_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`);

--
-- 限制表 `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- 限制表 `pictures`
--
ALTER TABLE `pictures`
  ADD CONSTRAINT `pictures_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- 限制表 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `products_ibfk_3` FOREIGN KEY (`category`) REFERENCES `categories` (`category_id`);

--
-- 限制表 `q_and_a`
--
ALTER TABLE `q_and_a`
  ADD CONSTRAINT `q_and_a_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `q_and_a_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `recommendation_records`
--
ALTER TABLE `recommendation_records`
  ADD CONSTRAINT `recommendation_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `recommendation_records_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- 限制表 `search_records`
--
ALTER TABLE `search_records`
  ADD CONSTRAINT `search_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `similarities`
--
ALTER TABLE `similarities`
  ADD CONSTRAINT `similarities_ibfk_1` FOREIGN KEY (`product1`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `similarities_ibfk_2` FOREIGN KEY (`product2`) REFERENCES `products` (`product_id`);

--
-- 限制表 `subscribe`
--
ALTER TABLE `subscribe`
  ADD CONSTRAINT `subscribe_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `subscribe_ibfk_2` FOREIGN KEY (`category`) REFERENCES `categories` (`category_id`);

--
-- 限制表 `token_for_new_password`
--
ALTER TABLE `token_for_new_password`
  ADD CONSTRAINT `token_for_new_password_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`address1`) REFERENCES `addresses` (`address_id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`campus`) REFERENCES `campuses` (`campus_id`),
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`school`) REFERENCES `schools` (`school_id`),
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`major`) REFERENCES `majors` (`major_id`);

--
-- 限制表 `visit_records`
--
ALTER TABLE `visit_records`
  ADD CONSTRAINT `visit_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `visit_records_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
